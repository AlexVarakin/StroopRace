#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy2 Experiment Builder (v1.82.01), Mon Aug 22 11:35:10 2016
If you publish work using this script please cite the relevant PsychoPy publications
  Peirce, JW (2007) PsychoPy - Psychophysics software in Python. Journal of Neuroscience Methods, 162(1-2), 8-13.
  Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy. Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import division  # so that 1/3=0.333 instead of 1/3=0
from psychopy import visual, core, data, event, logging, sound, gui
from psychopy.constants import *  # things like STARTED, FINISHED
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import sin, cos, tan, log, log10, pi, average, sqrt, std, deg2rad, rad2deg, linspace, asarray
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
expName = 'flankerTask'  # from the Builder filename that created this script
expInfo = {'participant':'', 'session':'001'}
dlg = gui.DlgFromDict(dictionary=expInfo, title=expName)
if dlg.OK == False: core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + 'data/%s_%s_%s' %(expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=u'/Users/Donald/Documents/Documents/EKU_Experiments/HPPSpaceCamp2016/flankerTask.psyexp',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
#save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(size=(1024, 768), fullscr=True, screen=0, allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True,
    )
# store frame rate of monitor if we can measure it successfully
expInfo['frameRate']=win.getActualFrameRate()
if expInfo['frameRate']!=None:
    frameDur = 1.0/round(expInfo['frameRate'])
else:
    frameDur = 1.0/60.0 # couldn't get a reliable measure so guess

# Initialize components for Routine "inst"
instClock = core.Clock()
instructions = visual.TextStim(win=win, ori=0, name='instructions',
    text='You will see a string of 5 arrows. Your job is to indicate the direction in which the central arrow is pointing using the arrow keys on the key board. If the central arrow is pointing left, press the left arrow. If the central arrow is pointing right, press the right arrow.\nPress the space bar to continue.',    font='Arial',
    pos=[0, 0], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0)

# Initialize components for Routine "trial"
trialClock = core.Clock()
ISI = core.StaticPeriod(win=win, screenHz=expInfo['frameRate'], name='ISI')
ArrowsText = visual.TextStim(win=win, ori=0, name='ArrowsText',
    text='default text',    font='Arial',
    pos=[0, 0], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-1.0)

# Initialize components for Routine "feedback"
feedbackClock = core.Clock()
inc_errors = 0.0
con_errors = 0.0
inc_rts = []
con_rts = []


textFeedback = visual.TextStim(win=win, ori=0, name='textFeedback',
    text='default text',    font='Arial',
    pos=[0, 0], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-1.0)

# Initialize components for Routine "endMsg"
endMsgClock = core.Clock()
endText = ""
conAvgRT = 0.
incAvgRT = 0.
conAcc = 0.
incAcc = 0.


def sumx(list):
    t = 0
    for i in range(len(list)):
        t += list[i-1]
    return t

def xbar(list):
    return sumx(list)/len(list)



textEnd = visual.TextStim(win=win, ori=0, name='textEnd',
    text='default text',    font='Arial',
    pos=[0, 0], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-1.0)

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

#------Prepare to start Routine "inst"-------
t = 0
instClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
inst_resp = event.BuilderKeyResponse()  # create an object of type KeyResponse
inst_resp.status = NOT_STARTED
# keep track of which components have finished
instComponents = []
instComponents.append(instructions)
instComponents.append(inst_resp)
for thisComponent in instComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "inst"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = instClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructions* updates
    if t >= 0.0 and instructions.status == NOT_STARTED:
        # keep track of start time/frame for later
        instructions.tStart = t  # underestimates by a little under one frame
        instructions.frameNStart = frameN  # exact frame index
        instructions.setAutoDraw(True)
    
    # *inst_resp* updates
    if t >= 0.0 and inst_resp.status == NOT_STARTED:
        # keep track of start time/frame for later
        inst_resp.tStart = t  # underestimates by a little under one frame
        inst_resp.frameNStart = frameN  # exact frame index
        inst_resp.status = STARTED
        # keyboard checking is just starting
        inst_resp.clock.reset()  # now t=0
        event.clearEvents(eventType='keyboard')
    if inst_resp.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            inst_resp.keys = theseKeys[-1]  # just the last key pressed
            inst_resp.rt = inst_resp.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "inst"-------
for thisComponent in instComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if inst_resp.keys in ['', [], None]:  # No response was made
   inst_resp.keys=None
# store data for thisExp (ExperimentHandler)
thisExp.addData('inst_resp.keys',inst_resp.keys)
if inst_resp.keys != None:  # we had a response
    thisExp.addData('inst_resp.rt', inst_resp.rt)
thisExp.nextEntry()
# the Routine "inst" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials = data.TrialHandler(nReps=5, method='random', 
    extraInfo=expInfo, originPath=u'/Users/Donald/Documents/Documents/EKU_Experiments/HPPSpaceCamp2016/flankerTask.psyexp',
    trialList=data.importConditions('flankerCond.xlsx', selection='0:4'),
    seed=None, name='trials')
thisExp.addLoop(trials)  # add the loop to the experiment
thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb=thisTrial.rgb)
if thisTrial != None:
    for paramName in thisTrial.keys():
        exec(paramName + '= thisTrial.' + paramName)

for thisTrial in trials:
    currentLoop = trials
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial.keys():
            exec(paramName + '= thisTrial.' + paramName)
    
    #------Prepare to start Routine "trial"-------
    t = 0
    trialClock.reset()  # clock 
    frameN = -1
    # update component parameters for each repeat
    ArrowsText.setText(Arrows)
    arrow_resp = event.BuilderKeyResponse()  # create an object of type KeyResponse
    arrow_resp.status = NOT_STARTED
    # keep track of which components have finished
    trialComponents = []
    trialComponents.append(ISI)
    trialComponents.append(ArrowsText)
    trialComponents.append(arrow_resp)
    for thisComponent in trialComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "trial"-------
    continueRoutine = True
    while continueRoutine:
        # get current time
        t = trialClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *ArrowsText* updates
        if t >= .5 and ArrowsText.status == NOT_STARTED:
            # keep track of start time/frame for later
            ArrowsText.tStart = t  # underestimates by a little under one frame
            ArrowsText.frameNStart = frameN  # exact frame index
            ArrowsText.setAutoDraw(True)
        
        # *arrow_resp* updates
        if t >= 0.5 and arrow_resp.status == NOT_STARTED:
            # keep track of start time/frame for later
            arrow_resp.tStart = t  # underestimates by a little under one frame
            arrow_resp.frameNStart = frameN  # exact frame index
            arrow_resp.status = STARTED
            # keyboard checking is just starting
            arrow_resp.clock.reset()  # now t=0
            event.clearEvents(eventType='keyboard')
        if arrow_resp.status == STARTED:
            theseKeys = event.getKeys(keyList=['left', 'right'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                arrow_resp.keys = theseKeys[-1]  # just the last key pressed
                arrow_resp.rt = arrow_resp.clock.getTime()
                # was this 'correct'?
                if (arrow_resp.keys == str(corrAns)) or (arrow_resp.keys == corrAns):
                    arrow_resp.corr = 1
                else:
                    arrow_resp.corr = 0
                # a response ends the routine
                continueRoutine = False
        # *ISI* period
        if t >= 0.0 and ISI.status == NOT_STARTED:
            # keep track of start time/frame for later
            ISI.tStart = t  # underestimates by a little under one frame
            ISI.frameNStart = frameN  # exact frame index
            ISI.start(0.5)
        elif ISI.status == STARTED: #one frame should pass before updating params and completing
            ISI.complete() #finish the static period
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    #-------Ending Routine "trial"-------
    for thisComponent in trialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if arrow_resp.keys in ['', [], None]:  # No response was made
       arrow_resp.keys=None
       # was no response the correct answer?!
       if str(corrAns).lower() == 'none': arrow_resp.corr = 1  # correct non-response
       else: arrow_resp.corr = 0  # failed to respond (incorrectly)
    # store data for trials (TrialHandler)
    trials.addData('arrow_resp.keys',arrow_resp.keys)
    trials.addData('arrow_resp.corr', arrow_resp.corr)
    if arrow_resp.keys != None:  # we had a response
        trials.addData('arrow_resp.rt', arrow_resp.rt)
    # the Routine "trial" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    #------Prepare to start Routine "feedback"-------
    t = 0
    feedbackClock.reset()  # clock 
    frameN = -1
    routineTimer.add(2.000000)
    # update component parameters for each repeat
    respTime0 = str(arrow_resp.rt)
    respTime = respTime0[0:4]
    
    if arrow_resp.keys == corrAns:
        msg = "Good Job. Your response time was " + respTime + " seconds"
        if Congruent == "con":
            con_rts.append(arrow_resp.rt)
        elif Congruent == "inc":
            inc_rts.append(arrow_resp.rt)
    else:
        msg = "Oops... looks like you pressed the wrong key"
        if Congruent == "con":
            con_errors += 1.0
        elif Congruent == "inc":
            inc_errors += 1.0
    textFeedback.setText(msg)
    # keep track of which components have finished
    feedbackComponents = []
    feedbackComponents.append(textFeedback)
    for thisComponent in feedbackComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "feedback"-------
    continueRoutine = True
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = feedbackClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        
        # *textFeedback* updates
        if t >= 0.0 and textFeedback.status == NOT_STARTED:
            # keep track of start time/frame for later
            textFeedback.tStart = t  # underestimates by a little under one frame
            textFeedback.frameNStart = frameN  # exact frame index
            textFeedback.setAutoDraw(True)
        if textFeedback.status == STARTED and t >= (0.0 + (2.0-win.monitorFramePeriod*0.75)): #most of one frame period left
            textFeedback.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in feedbackComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    #-------Ending Routine "feedback"-------
    for thisComponent in feedbackComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    
    thisExp.nextEntry()
    
# completed 5 repeats of 'trials'


#------Prepare to start Routine "endMsg"-------
t = 0
endMsgClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
conAvgRT = xbar(con_rts)
incAvgRT = xbar(inc_rts)
conAcc = 1 - (con_errors/(con_errors + len(con_rts)))
incAcc = 1 - (inc_errors/(inc_errors + len(inc_rts)))

endText = "Your average congruent trial response time was " + str(conAvgRT)[0:4] + " seconds.\nYour average incongruent trial response time was " + str(incAvgRT)[0:4] + " seconds.\nYour congruent accuracy was " + str(conAcc)[0:4] + ".\nYour incongruent accuracy was " + str(incAcc)[0:4] + "."

textEnd.setText(endText)
key_resp_2 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_2.status = NOT_STARTED
# keep track of which components have finished
endMsgComponents = []
endMsgComponents.append(textEnd)
endMsgComponents.append(key_resp_2)
for thisComponent in endMsgComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "endMsg"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = endMsgClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    
    # *textEnd* updates
    if t >= 0.0 and textEnd.status == NOT_STARTED:
        # keep track of start time/frame for later
        textEnd.tStart = t  # underestimates by a little under one frame
        textEnd.frameNStart = frameN  # exact frame index
        textEnd.setAutoDraw(True)
    
    # *key_resp_2* updates
    if t >= 0.0 and key_resp_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_2.tStart = t  # underestimates by a little under one frame
        key_resp_2.frameNStart = frameN  # exact frame index
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        key_resp_2.clock.reset()  # now t=0
        event.clearEvents(eventType='keyboard')
    if key_resp_2.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_2.keys = theseKeys[-1]  # just the last key pressed
            key_resp_2.rt = key_resp_2.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in endMsgComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "endMsg"-------
for thisComponent in endMsgComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# check responses
if key_resp_2.keys in ['', [], None]:  # No response was made
   key_resp_2.keys=None
# store data for thisExp (ExperimentHandler)
thisExp.addData('key_resp_2.keys',key_resp_2.keys)
if key_resp_2.keys != None:  # we had a response
    thisExp.addData('key_resp_2.rt', key_resp_2.rt)
thisExp.nextEntry()
# the Routine "endMsg" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()


win.close()
core.quit()

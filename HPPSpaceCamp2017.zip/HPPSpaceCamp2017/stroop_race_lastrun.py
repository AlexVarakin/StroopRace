#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy2 Experiment Builder (v1.82.01), Thu Apr 13 12:32:12 2017
If you publish work using this script please cite the relevant PsychoPy publications
  Peirce, JW (2007) PsychoPy - Psychophysics software in Python. Journal of Neuroscience Methods, 162(1-2), 8-13.
  Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy. Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import division  # so that 1/3=0.333 instead of 1/3=0
from psychopy import visual, core, data, event, logging, sound, gui
from psychopy.constants import *  # things like STARTED, FINISHED
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import sin, cos, tan, log, log10, pi, average, sqrt, std, deg2rad, rad2deg, linspace, asarray
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
expName = 'stroop_race'  # from the Builder filename that created this script
expInfo = {'participant':'', 'session':'001'}
dlg = gui.DlgFromDict(dictionary=expInfo, title=expName)
if dlg.OK == False: core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + 'data/%s_%s_%s' %(expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=u'/Users/Donald/Documents/Documents/EKU_Experiments/HPPSpaceCamp2016/stroop_race.psyexp',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
#save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(size=(1280, 800), fullscr=True, screen=0, allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True,
    )
# store frame rate of monitor if we can measure it successfully
expInfo['frameRate']=win.getActualFrameRate()
if expInfo['frameRate']!=None:
    frameDur = 1.0/round(expInfo['frameRate'])
else:
    frameDur = 1.0/60.0 # couldn't get a reliable measure so guess

# Initialize components for Routine "Inst"
InstClock = core.Clock()
import random
choices = ["red","yellow","blue"]
redInk = "red"
blueInk = "blue"
yellowInk = "yellow"
title = visual.TextStim(win=win, ori=0, name='title',
    text='STROOP RACE',    font='Arial',
    pos=[0, 0], height=0.5, wrapWidth=None,
    color='black', colorSpace='rgb', opacity=1,
    depth=-1.0)
red = visual.TextStim(win=win, ori=0, name='red',
    text='red',    font='Arial',
    pos=[-.3, 0], height=0.1, wrapWidth=None,
    color=1.0, colorSpace='rgb', opacity=1,
    depth=-3.0)
blue = visual.TextStim(win=win, ori=0, name='blue',
    text='blue',    font='Arial',
    pos=[0, 0], height=0.1, wrapWidth=None,
    color=1.0, colorSpace='rgb', opacity=1,
    depth=-4.0)
yellow = visual.TextStim(win=win, ori=0, name='yellow',
    text='yellow',    font='Arial',
    pos=[.3, 0], height=0.1, wrapWidth=None,
    color=1.0, colorSpace='rgb', opacity=1,
    depth=-5.0)

# Initialize components for Routine "Inst2"
Inst2Clock = core.Clock()
instructions = "On each trial of this experiment, you'll see a color name. Your job is to identify the color of the *ink* in which the color name is printed. Sometimes the color name and ink will match (e.g. red in red ink), sometimes they won't (e.g. red in blue ink!"

p1inst = "Player 1:\nred ink... press 'z'\nyellow ink... press'x'\nblue ink... press 'c'"
p2inst = "Player 2:\nred ink... press 'left'\nyellow ink... press'down'\nblue ink... press 'right'"
text_3 = visual.TextStim(win=win, ori=0, name='text_3',
    text=instructions,    font='Arial',
    pos=[0, .5], height=0.1, wrapWidth=1.5,
    color='white', colorSpace='rgb', opacity=1,
    depth=-1.0)
p1instr = visual.TextStim(win=win, ori=0, name='p1instr',
    text=p1inst,    font='Arial',
    pos=[-.5, -.5], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-2.0)
p2instr = visual.TextStim(win=win, ori=0, name='p2instr',
    text=p2inst,    font='Arial',
    pos=[.5, -.5], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-3.0)
red_red = visual.TextStim(win=win, ori=0, name='red_red',
    text='red',    font='Arial',
    pos=[-.3, 0], height=0.1, wrapWidth=None,
    color='red', colorSpace='rgb', opacity=1,
    depth=-4.0)
red_blue = visual.TextStim(win=win, ori=0, name='red_blue',
    text='red',    font='Arial',
    pos=[.3, 0], height=0.1, wrapWidth=None,
    color='blue', colorSpace='rgb', opacity=1,
    depth=-5.0)

# Initialize components for Routine "inst3"
inst3Clock = core.Clock()
text_4 = visual.TextStim(win=win, ori=0, name='text_4',
    text='Each trial is a race! The player with the fastest ACCURATE response wins the trial. If the word and color match, 1 points is awarded. If the word and color do not match, 2 points are awarded. At the end of the game, the player with the most points wins. If both players have the same number of points, the player with the fastest average winning response time will win.',    font='Arial',
    pos=[0, 0], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0)

# Initialize components for Routine "trial"
trialClock = core.Clock()
ISI = core.StaticPeriod(win=win, screenHz=expInfo['frameRate'], name='ISI')
text = visual.TextStim(win=win, ori=0, name='text',
    text='default text',    font='Arial',
    pos=[0, 0], height=0.1, wrapWidth=None,
    color=1.0, colorSpace='rgb', opacity=1,
    depth=-1.0)


# Initialize components for Routine "feedback"
feedbackClock = core.Clock()
msg = "Hello World!"

p1points = 0
p2points = 0
points = 0

p1msg = "Player 1: " + str(p1points) + " points"
p2msg = "Player 2: " + str(p2points) + " points"

p1rts = []
p2rts = []
p1avg = 0.0
p2avg = 0.0
p1avgstr = "0"
p2avgstr = "0"

def sumx(list):
    t = 0
    for i in range(len(list)):
        t += list[i-1]
    return t

def xbar(list):
    return sumx(list)/len(list)
text_2 = visual.TextStim(win=win, ori=0, name='text_2',
    text='default text',    font='Arial',
    pos=[0, .5], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-1.0)
player1_msg = visual.TextStim(win=win, ori=0, name='player1_msg',
    text='default text',    font='Arial',
    pos=[-.5, 0], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-2.0)
player2_msg = visual.TextStim(win=win, ori=0, name='player2_msg',
    text='default text',    font='Arial',
    pos=[.5, 0], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-3.0)
end_msg = visual.TextStim(win=win, ori=0, name='end_msg',
    text='Press space for the next trial',    font='Arial',
    pos=[0, -.5], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-4.0)

# Initialize components for Routine "End"
EndClock = core.Clock()
theWinner = ""
p1Rslt = ""
p2Rslt = ""
winner = visual.TextStim(win=win, ori=0, name='winner',
    text='default text',    font='Arial',
    pos=[0, 0.5], height=0.2, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-1.0)
p1results = visual.TextStim(win=win, ori=0, name='p1results',
    text='default text',    font='Arial',
    pos=[-.5, 0], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-2.0)
p2results = visual.TextStim(win=win, ori=0, name='p2results',
    text='default text',    font='Arial',
    pos=[0.5, 0], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-3.0)

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

#------Prepare to start Routine "Inst"-------
t = 0
InstClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
redInk = random.choice(choices)
blueInk = random.choice(choices)
yellowInk = random.choice(choices)
key_resp_3 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_3.status = NOT_STARTED
# keep track of which components have finished
InstComponents = []
InstComponents.append(title)
InstComponents.append(key_resp_3)
InstComponents.append(red)
InstComponents.append(blue)
InstComponents.append(yellow)
for thisComponent in InstComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "Inst"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = InstClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    if frameN%30 == 0:
        redInk = random.choice(choices)
        blueInk = random.choice(choices)
        yellowInk = random.choice(choices)
    
    # *title* updates
    if t >= 0.0 and title.status == NOT_STARTED:
        # keep track of start time/frame for later
        title.tStart = t  # underestimates by a little under one frame
        title.frameNStart = frameN  # exact frame index
        title.setAutoDraw(True)
    
    # *key_resp_3* updates
    if t >= 0.0 and key_resp_3.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_3.tStart = t  # underestimates by a little under one frame
        key_resp_3.frameNStart = frameN  # exact frame index
        key_resp_3.status = STARTED
        # keyboard checking is just starting
        key_resp_3.clock.reset()  # now t=0
        event.clearEvents(eventType='keyboard')
    if key_resp_3.status == STARTED:
        theseKeys = event.getKeys(keyList=['y', 'n', 'left', 'right', 'space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_3.keys = theseKeys[-1]  # just the last key pressed
            key_resp_3.rt = key_resp_3.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # *red* updates
    if t >= 0.0 and red.status == NOT_STARTED:
        # keep track of start time/frame for later
        red.tStart = t  # underestimates by a little under one frame
        red.frameNStart = frameN  # exact frame index
        red.setAutoDraw(True)
    if red.status == STARTED:  # only update if being drawn
        red.setColor(redInk, colorSpace='rgb', log=False)
    
    # *blue* updates
    if t >= 0.0 and blue.status == NOT_STARTED:
        # keep track of start time/frame for later
        blue.tStart = t  # underestimates by a little under one frame
        blue.frameNStart = frameN  # exact frame index
        blue.setAutoDraw(True)
    if blue.status == STARTED:  # only update if being drawn
        blue.setColor(blueInk, colorSpace='rgb', log=False)
    
    # *yellow* updates
    if t >= 0.0 and yellow.status == NOT_STARTED:
        # keep track of start time/frame for later
        yellow.tStart = t  # underestimates by a little under one frame
        yellow.frameNStart = frameN  # exact frame index
        yellow.setAutoDraw(True)
    if yellow.status == STARTED:  # only update if being drawn
        yellow.setColor(yellowInk, colorSpace='rgb', log=False)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in InstComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "Inst"-------
for thisComponent in InstComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# check responses
if key_resp_3.keys in ['', [], None]:  # No response was made
   key_resp_3.keys=None
# store data for thisExp (ExperimentHandler)
thisExp.addData('key_resp_3.keys',key_resp_3.keys)
if key_resp_3.keys != None:  # we had a response
    thisExp.addData('key_resp_3.rt', key_resp_3.rt)
thisExp.nextEntry()
# the Routine "Inst" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

#------Prepare to start Routine "Inst2"-------
t = 0
Inst2Clock.reset()  # clock 
frameN = -1
# update component parameters for each repeat

key_resp_4 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_4.status = NOT_STARTED
# keep track of which components have finished
Inst2Components = []
Inst2Components.append(text_3)
Inst2Components.append(p1instr)
Inst2Components.append(p2instr)
Inst2Components.append(red_red)
Inst2Components.append(red_blue)
Inst2Components.append(key_resp_4)
for thisComponent in Inst2Components:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "Inst2"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = Inst2Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    
    # *text_3* updates
    if t >= 0.0 and text_3.status == NOT_STARTED:
        # keep track of start time/frame for later
        text_3.tStart = t  # underestimates by a little under one frame
        text_3.frameNStart = frameN  # exact frame index
        text_3.setAutoDraw(True)
    
    # *p1instr* updates
    if t >= 0.0 and p1instr.status == NOT_STARTED:
        # keep track of start time/frame for later
        p1instr.tStart = t  # underestimates by a little under one frame
        p1instr.frameNStart = frameN  # exact frame index
        p1instr.setAutoDraw(True)
    
    # *p2instr* updates
    if t >= 0.0 and p2instr.status == NOT_STARTED:
        # keep track of start time/frame for later
        p2instr.tStart = t  # underestimates by a little under one frame
        p2instr.frameNStart = frameN  # exact frame index
        p2instr.setAutoDraw(True)
    
    # *red_red* updates
    if t >= 0.0 and red_red.status == NOT_STARTED:
        # keep track of start time/frame for later
        red_red.tStart = t  # underestimates by a little under one frame
        red_red.frameNStart = frameN  # exact frame index
        red_red.setAutoDraw(True)
    
    # *red_blue* updates
    if t >= 0.0 and red_blue.status == NOT_STARTED:
        # keep track of start time/frame for later
        red_blue.tStart = t  # underestimates by a little under one frame
        red_blue.frameNStart = frameN  # exact frame index
        red_blue.setAutoDraw(True)
    
    # *key_resp_4* updates
    if t >= 0.0 and key_resp_4.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_4.tStart = t  # underestimates by a little under one frame
        key_resp_4.frameNStart = frameN  # exact frame index
        key_resp_4.status = STARTED
        # keyboard checking is just starting
        key_resp_4.clock.reset()  # now t=0
        event.clearEvents(eventType='keyboard')
    if key_resp_4.status == STARTED:
        theseKeys = event.getKeys(keyList=['y', 'n', 'left', 'right', 'space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_4.keys = theseKeys[-1]  # just the last key pressed
            key_resp_4.rt = key_resp_4.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Inst2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "Inst2"-------
for thisComponent in Inst2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# check responses
if key_resp_4.keys in ['', [], None]:  # No response was made
   key_resp_4.keys=None
# store data for thisExp (ExperimentHandler)
thisExp.addData('key_resp_4.keys',key_resp_4.keys)
if key_resp_4.keys != None:  # we had a response
    thisExp.addData('key_resp_4.rt', key_resp_4.rt)
thisExp.nextEntry()
# the Routine "Inst2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

#------Prepare to start Routine "inst3"-------
t = 0
inst3Clock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
key_resp_5 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_5.status = NOT_STARTED
# keep track of which components have finished
inst3Components = []
inst3Components.append(text_4)
inst3Components.append(key_resp_5)
for thisComponent in inst3Components:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "inst3"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = inst3Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_4* updates
    if t >= 0.0 and text_4.status == NOT_STARTED:
        # keep track of start time/frame for later
        text_4.tStart = t  # underestimates by a little under one frame
        text_4.frameNStart = frameN  # exact frame index
        text_4.setAutoDraw(True)
    
    # *key_resp_5* updates
    if t >= 0.0 and key_resp_5.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_5.tStart = t  # underestimates by a little under one frame
        key_resp_5.frameNStart = frameN  # exact frame index
        key_resp_5.status = STARTED
        # keyboard checking is just starting
        key_resp_5.clock.reset()  # now t=0
        event.clearEvents(eventType='keyboard')
    if key_resp_5.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_5.keys = theseKeys[-1]  # just the last key pressed
            key_resp_5.rt = key_resp_5.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in inst3Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "inst3"-------
for thisComponent in inst3Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_resp_5.keys in ['', [], None]:  # No response was made
   key_resp_5.keys=None
# store data for thisExp (ExperimentHandler)
thisExp.addData('key_resp_5.keys',key_resp_5.keys)
if key_resp_5.keys != None:  # we had a response
    thisExp.addData('key_resp_5.rt', key_resp_5.rt)
thisExp.nextEntry()
# the Routine "inst3" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials = data.TrialHandler(nReps=3, method='random', 
    extraInfo=expInfo, originPath=u'/Users/Donald/Documents/Documents/EKU_Experiments/HPPSpaceCamp2016/stroop_race.psyexp',
    trialList=data.importConditions('conditions.xlsx'),
    seed=None, name='trials')
thisExp.addLoop(trials)  # add the loop to the experiment
thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb=thisTrial.rgb)
if thisTrial != None:
    for paramName in thisTrial.keys():
        exec(paramName + '= thisTrial.' + paramName)

for thisTrial in trials:
    currentLoop = trials
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial.keys():
            exec(paramName + '= thisTrial.' + paramName)
    
    #------Prepare to start Routine "trial"-------
    t = 0
    trialClock.reset()  # clock 
    frameN = -1
    routineTimer.add(5.500000)
    # update component parameters for each repeat
    text.setColor(color, colorSpace='rgb')
    text.setText(word)
    p1resp = event.BuilderKeyResponse()  # create an object of type KeyResponse
    p1resp.status = NOT_STARTED
    p2resp = event.BuilderKeyResponse()  # create an object of type KeyResponse
    p2resp.status = NOT_STARTED
    
    # keep track of which components have finished
    trialComponents = []
    trialComponents.append(ISI)
    trialComponents.append(text)
    trialComponents.append(p1resp)
    trialComponents.append(p2resp)
    for thisComponent in trialComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "trial"-------
    continueRoutine = True
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = trialClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text* updates
        if t >= .5 and text.status == NOT_STARTED:
            # keep track of start time/frame for later
            text.tStart = t  # underestimates by a little under one frame
            text.frameNStart = frameN  # exact frame index
            text.setAutoDraw(True)
        if text.status == STARTED and t >= (.5 + (5-win.monitorFramePeriod*0.75)): #most of one frame period left
            text.setAutoDraw(False)
        
        # *p1resp* updates
        if t >= 0.5 and p1resp.status == NOT_STARTED:
            # keep track of start time/frame for later
            p1resp.tStart = t  # underestimates by a little under one frame
            p1resp.frameNStart = frameN  # exact frame index
            p1resp.status = STARTED
            # keyboard checking is just starting
            p1resp.clock.reset()  # now t=0
        if p1resp.status == STARTED and t >= (0.5 + (5.0-win.monitorFramePeriod*0.75)): #most of one frame period left
            p1resp.status = STOPPED
        if p1resp.status == STARTED:
            theseKeys = event.getKeys(keyList=['z', 'x', 'c'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                if p1resp.keys == []:  # then this was the first keypress
                    p1resp.keys = theseKeys[0]  # just the first key pressed
                    p1resp.rt = p1resp.clock.getTime()
                    # was this 'correct'?
                    if (p1resp.keys == str('corrAns1')) or (p1resp.keys == 'corrAns1'):
                        p1resp.corr = 1
                    else:
                        p1resp.corr = 0
        
        # *p2resp* updates
        if t >= 0.5 and p2resp.status == NOT_STARTED:
            # keep track of start time/frame for later
            p2resp.tStart = t  # underestimates by a little under one frame
            p2resp.frameNStart = frameN  # exact frame index
            p2resp.status = STARTED
            # keyboard checking is just starting
            p2resp.clock.reset()  # now t=0
        if p2resp.status == STARTED and t >= (0.5 + (5.0-win.monitorFramePeriod*0.75)): #most of one frame period left
            p2resp.status = STOPPED
        if p2resp.status == STARTED:
            theseKeys = event.getKeys(keyList=['left', 'down', 'right'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                if p2resp.keys == []:  # then this was the first keypress
                    p2resp.keys = theseKeys[0]  # just the first key pressed
                    p2resp.rt = p2resp.clock.getTime()
                    # was this 'correct'?
                    if (p2resp.keys == str('corrAns2')) or (p2resp.keys == 'corrAns2'):
                        p2resp.corr = 1
                    else:
                        p2resp.corr = 0
        if len(p1resp.keys) > 0 and len(p2resp.keys) > 0:
            break
        
        # *ISI* period
        if t >= 0.0 and ISI.status == NOT_STARTED:
            # keep track of start time/frame for later
            ISI.tStart = t  # underestimates by a little under one frame
            ISI.frameNStart = frameN  # exact frame index
            ISI.start(0.5)
        elif ISI.status == STARTED: #one frame should pass before updating params and completing
            ISI.complete() #finish the static period
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    #-------Ending Routine "trial"-------
    for thisComponent in trialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if p1resp.keys in ['', [], None]:  # No response was made
       p1resp.keys=None
       # was no response the correct answer?!
       if str('corrAns1').lower() == 'none': p1resp.corr = 1  # correct non-response
       else: p1resp.corr = 0  # failed to respond (incorrectly)
    # store data for trials (TrialHandler)
    trials.addData('p1resp.keys',p1resp.keys)
    trials.addData('p1resp.corr', p1resp.corr)
    if p1resp.keys != None:  # we had a response
        trials.addData('p1resp.rt', p1resp.rt)
    # check responses
    if p2resp.keys in ['', [], None]:  # No response was made
       p2resp.keys=None
       # was no response the correct answer?!
       if str('corrAns2').lower() == 'none': p2resp.corr = 1  # correct non-response
       else: p2resp.corr = 0  # failed to respond (incorrectly)
    # store data for trials (TrialHandler)
    trials.addData('p2resp.keys',p2resp.keys)
    trials.addData('p2resp.corr', p2resp.corr)
    if p2resp.keys != None:  # we had a response
        trials.addData('p2resp.rt', p2resp.rt)
    
    
    #------Prepare to start Routine "feedback"-------
    t = 0
    feedbackClock.reset()  # clock 
    frameN = -1
    # update component parameters for each repeat
    if congruent == 1:
        points = 1
    if congruent == 0:
        points = 2
    
    if p1resp.keys != corrAns1 and p2resp.keys != corrAns2:
        msg = "Did y'all forget how to respond?"
    elif p1resp.keys != corrAns1 and p2resp.keys == corrAns2:
        p2points += points
        msg = "Player 2 wins!"
    elif p1resp.keys == corrAns1 and p2resp.keys != corrAns2:
        p1points += points
        msg = "Player 1 wins!"
    elif p1resp.rt < p2resp.rt:
        p1points += points
        msg = "Player 1 wins!"
    elif p2resp.rt < p1resp.rt:
        p2points += points
        msg = "Player 2 wins!"
    elif p2resp.rt == p1resp.rt:
        msg = "It's a tie!"
    
    if msg == "Player 1 wins!":
        p1rts.append(p1resp.rt)
    if msg == "Player 2 wins!":
        p2rts.append(p2resp.rt)
    
    if len(p1rts) > 0:
        p1avg = xbar(p1rts)
        p1avgstr = str(p1avg)
    if len(p2rts) > 0:
        p2avg = xbar(p2rts)
        p2avgstr = str(p2avg)
    
    p1msg = "Player 1: " + str(p1points) + " points." + " \nAvg winning RT is " + str(p1avgstr[0:5]) + " sec."
    p2msg = "Player 2: " + str(p2points) + " points." + " \nAvg winning RT is " + str(p2avgstr[0:5]) + " sec."
    
    text_2.setText(msg)
    player1_msg.setText(p1msg)
    player2_msg.setText(p2msg)
    end_feedback = event.BuilderKeyResponse()  # create an object of type KeyResponse
    end_feedback.status = NOT_STARTED
    # keep track of which components have finished
    feedbackComponents = []
    feedbackComponents.append(text_2)
    feedbackComponents.append(player1_msg)
    feedbackComponents.append(player2_msg)
    feedbackComponents.append(end_msg)
    feedbackComponents.append(end_feedback)
    for thisComponent in feedbackComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "feedback"-------
    continueRoutine = True
    while continueRoutine:
        # get current time
        t = feedbackClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        
        # *text_2* updates
        if t >= 0.0 and text_2.status == NOT_STARTED:
            # keep track of start time/frame for later
            text_2.tStart = t  # underestimates by a little under one frame
            text_2.frameNStart = frameN  # exact frame index
            text_2.setAutoDraw(True)
        
        # *player1_msg* updates
        if t >= 0.0 and player1_msg.status == NOT_STARTED:
            # keep track of start time/frame for later
            player1_msg.tStart = t  # underestimates by a little under one frame
            player1_msg.frameNStart = frameN  # exact frame index
            player1_msg.setAutoDraw(True)
        
        # *player2_msg* updates
        if t >= 0.0 and player2_msg.status == NOT_STARTED:
            # keep track of start time/frame for later
            player2_msg.tStart = t  # underestimates by a little under one frame
            player2_msg.frameNStart = frameN  # exact frame index
            player2_msg.setAutoDraw(True)
        
        # *end_msg* updates
        if t >= 0.0 and end_msg.status == NOT_STARTED:
            # keep track of start time/frame for later
            end_msg.tStart = t  # underestimates by a little under one frame
            end_msg.frameNStart = frameN  # exact frame index
            end_msg.setAutoDraw(True)
        
        # *end_feedback* updates
        if t >= 0.0 and end_feedback.status == NOT_STARTED:
            # keep track of start time/frame for later
            end_feedback.tStart = t  # underestimates by a little under one frame
            end_feedback.frameNStart = frameN  # exact frame index
            end_feedback.status = STARTED
            # keyboard checking is just starting
            end_feedback.clock.reset()  # now t=0
            event.clearEvents(eventType='keyboard')
        if end_feedback.status == STARTED:
            theseKeys = event.getKeys(keyList=['space'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                end_feedback.keys = theseKeys[-1]  # just the last key pressed
                end_feedback.rt = end_feedback.clock.getTime()
                # a response ends the routine
                continueRoutine = False
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in feedbackComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    #-------Ending Routine "feedback"-------
    for thisComponent in feedbackComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    
    # check responses
    if end_feedback.keys in ['', [], None]:  # No response was made
       end_feedback.keys=None
    # store data for trials (TrialHandler)
    trials.addData('end_feedback.keys',end_feedback.keys)
    if end_feedback.keys != None:  # we had a response
        trials.addData('end_feedback.rt', end_feedback.rt)
    # the Routine "feedback" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 3 repeats of 'trials'


#------Prepare to start Routine "End"-------
t = 0
EndClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
if p1points > p2points:
    theWinner = "Player 1 wins!"
elif p2points > p1points:
    theWinner = "Player 2 wins!"
elif p2points == p1points:
    if p1avg < p2avg: theWinner = "Player 1 wins!"
    elif p2avg < p1avg: theWinner = "Player 2 wins!"
    else: theWinner = "It's a Tie"

p1Rslt = "Player 1: " + str(p1points) + " points." + " \nAvg winning RT is " + str(p1avgstr[0:5]) + " sec."
p2Rslt = "Player 2: " + str(p2points) + " points." + " \nAvg winning RT is " + str(p2avgstr[0:5]) + " sec."
winner.setText(theWinner)
p1results.setText(p1Rslt)
p2results.setText(p2Rslt)
key_resp_2 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_2.status = NOT_STARTED
# keep track of which components have finished
EndComponents = []
EndComponents.append(winner)
EndComponents.append(p1results)
EndComponents.append(p2results)
EndComponents.append(key_resp_2)
for thisComponent in EndComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "End"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = EndClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    
    # *winner* updates
    if t >= .5 and winner.status == NOT_STARTED:
        # keep track of start time/frame for later
        winner.tStart = t  # underestimates by a little under one frame
        winner.frameNStart = frameN  # exact frame index
        winner.setAutoDraw(True)
    
    # *p1results* updates
    if t >= 0.0 and p1results.status == NOT_STARTED:
        # keep track of start time/frame for later
        p1results.tStart = t  # underestimates by a little under one frame
        p1results.frameNStart = frameN  # exact frame index
        p1results.setAutoDraw(True)
    
    # *p2results* updates
    if t >= 0.0 and p2results.status == NOT_STARTED:
        # keep track of start time/frame for later
        p2results.tStart = t  # underestimates by a little under one frame
        p2results.frameNStart = frameN  # exact frame index
        p2results.setAutoDraw(True)
    
    # *key_resp_2* updates
    if t >= 0.0 and key_resp_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_2.tStart = t  # underestimates by a little under one frame
        key_resp_2.frameNStart = frameN  # exact frame index
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        key_resp_2.clock.reset()  # now t=0
        event.clearEvents(eventType='keyboard')
    if key_resp_2.status == STARTED:
        theseKeys = event.getKeys(keyList=['y', 'n', 'left', 'right', 'space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_resp_2.keys = theseKeys[-1]  # just the last key pressed
            key_resp_2.rt = key_resp_2.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in EndComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "End"-------
for thisComponent in EndComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# check responses
if key_resp_2.keys in ['', [], None]:  # No response was made
   key_resp_2.keys=None
# store data for thisExp (ExperimentHandler)
thisExp.addData('key_resp_2.keys',key_resp_2.keys)
if key_resp_2.keys != None:  # we had a response
    thisExp.addData('key_resp_2.rt', key_resp_2.rt)
thisExp.nextEntry()
# the Routine "End" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()





win.close()
core.quit()
